# 🛍️ Product Information Server

A simple Node.js + Express API to serve and add product data.

## 🚀 Features
- Express server on port 4000
- `/routes/products.js` handles product routes
- `GET /products` → returns all products
- `POST /products` → adds a new product
- Uses `os` module to print system info
- Logs each request (method + URL) using `http` module
- Includes CORS and JSON middleware

## 🧠 Run Instructions

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the server:
   ```bash
   npm start
   ```

3. Test endpoints:
   - GET → http://localhost:4000/products
   - POST → http://localhost:4000/products
     ```json
     {
       "name": "Tablet",
       "price": 15000
     }
     ```
