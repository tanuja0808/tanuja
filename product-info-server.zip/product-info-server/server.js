const express = require('express');
const http = require('http');
const os = require('os');
const cors = require('cors');
const productRoutes = require('./routes/products');

const app = express();
const PORT = 4000;

// Middleware
app.use(cors());
app.use(express.json());

// Custom middleware using http module to log requests
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

// Routes
app.use('/products', productRoutes);

// System info using os module
console.log('--- System Information ---');
console.log('Platform:', os.platform());
console.log('CPU Cores:', os.cpus().length);
console.log('Architecture:', os.arch());
console.log('---------------------------');

// Start server
const server = http.createServer(app);
server.listen(PORT, () => {
  console.log(`🚀 Product Information Server running on http://localhost:${PORT}`);
});
